﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorApp.Shared.BAL.Services.UsersService;
using BlazorApp.Shared.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BlazorApp.Shared.BAL.Interfaces;
namespace BlazorApp.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly BlazorContext _context;
        private readonly IUsersService _userService;
        public UsersController(BlazorContext context, IUsersService userService)
        {
           this._context = context;
            this._userService = userService;
        }

        [HttpGet]
        public IEnumerable<Users> Get()
        {
            var users = _userService.GetAll();
            return users;
            
        }
        
        [HttpPost]
        public IActionResult Create([FromBody]Users users)
        {
            var result = false;
            if (ModelState.IsValid)
                result=_userService.Add(users);
            if (result)
                return new JsonResult(result);
            return new BadRequestObjectResult("Error in adding user!");

        }

        [HttpGet("{Id}")]
        public Users Get([FromRoute] long Id)
        {
            Users model = null;
            if(Id>0)
                model = _userService.Get(Id);
            return model;
        }
        [HttpPut]
        public IActionResult Update([FromBody]Users users)
        {
            var result = false;
            if (ModelState.IsValid)
                result = _userService.Update(users);
            if (result)
            {
                return new JsonResult(result);
            }
            return new BadRequestObjectResult("Error in updating user!");
        }


        [HttpDelete("{Id}")]
        public IActionResult Delete([FromRoute] long Id)
        {

            Users model = null;
            bool result = false;
            if (Id > 0)
                model = _userService.Get(Id);

            if (model != null)
                result = _userService.Delete(model);
            else
                return new BadRequestObjectResult("User doest not exist!");

            return new BadRequestObjectResult("Error in deleting user!");


        }

    }
}