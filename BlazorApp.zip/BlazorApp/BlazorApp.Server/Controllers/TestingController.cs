﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
 
using BlazorApp.Shared.BAL.Services.UsersService;
using BlazorApp.Shared.Model;
using Microsoft.AspNetCore.Http;
 
using BlazorApp.Shared.BAL.Interfaces;
namespace BlazorApp.Server.Controllers
{
    public class TestingController : Controller
    {

        private readonly BlazorContext _context;
        private readonly IUsersService _userService;
        public TestingController(BlazorContext context, IUsersService userService)
        {
            this._context = context;
            this._userService = userService;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [Route("api/testing/create")]
        public void Create([FromBody]UserViewModel users)
        {
            Users model = new Users();
            var result = _userService.Add(model);
            //if (users != null)
            //{
            //   return new OkObjectResult(users);
            //}
            //    return BadRequest("Error in finding users");
            //await _context.SaveChangesAsync();
            //return true;
        }
    }
}