﻿using BlazorApp.Shared.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorApp.Shared.BAL.Interfaces
{
   public interface IUsersService
    {
        bool Add(Users model);
        bool Update(Users model);
        bool Delete(Users model);
        Users Get(Int64 id);
        List<Users> GetAll();
    }
}
