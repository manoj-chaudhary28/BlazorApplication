﻿using BlazorApp.Shared.BAL.Interfaces;
using BlazorApp.Shared.DAL.Interfaces;
using BlazorApp.Shared.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlazorApp.Shared.BAL.Services.UsersService
{
    public class UsersService : IUsersService
    {
         
        private IUnitOfWork unitOfWork;
        public UsersService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
         

        public bool Add(Users model)
        {
            bool returnVal;
            try
            {
                returnVal = unitOfWork.UserRepo.Insert(model);
            }
            catch
            {
                returnVal = false;
            }
            return returnVal;
        }
        public bool Update(Users model)
        {
            bool returnVal;
            try
            {
                returnVal = unitOfWork.UserRepo.Update(model);
            }
            catch
            {
                returnVal = false;
            }
            return returnVal;
        }
        public bool Delete(Users model)
        {
            bool returnVal;
            try
            {
                returnVal = unitOfWork.UserRepo.Delete(model);
            }
            catch
            {
                returnVal = false;
            }
            return returnVal;
        }
        public Users Get(Int64 Id)
        {
            Users model =null;
            try
            {
                model = unitOfWork.UserRepo.Get(Id);
            }
            catch
            {
               
            } 
            return model;
        }
        public List<Users> GetAll()
        {
            var users = unitOfWork.UserRepo.GetAll();
            return users !=null ? users.ToList(): new List<Users>();
        }
    }
}
