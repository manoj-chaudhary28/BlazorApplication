﻿using BlazorApp.Shared.DAL.Interfaces;
using BlazorApp.Shared.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorApp.Shared.DAL
{
    public class UnitOfWork : IUnitOfWork
    {
        private IRepository<Users> userRepo;
       
        private BlazorContext context;
        public UnitOfWork(BlazorContext context)
        {
            this.context = context;
        }
        public IRepository<Users> UserRepo
        {
            get
            {
                if (userRepo == null)
                {
                    userRepo = new Repository<Users>(context);
                }
                return userRepo;
            }
        }

        
        public void Save()
        {
            context.SaveChanges();
        }
    }
}
