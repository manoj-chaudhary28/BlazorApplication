﻿using BlazorApp.Shared.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorApp.Shared.DAL.Interfaces
{
    public interface IUnitOfWork
    {
        IRepository<Users> UserRepo { get; }
        void Save();
    }
}
