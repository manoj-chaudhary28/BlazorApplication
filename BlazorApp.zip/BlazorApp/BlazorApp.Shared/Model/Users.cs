﻿using System;
using System.Collections.Generic;

namespace BlazorApp.Shared.Model
{
    public partial class Users:BaseModel
    {
        public Users()
        {
            UserMemberShip = new HashSet<UserMemberShip>();
            UserProfile = new HashSet<UserProfile>();
        }

        //public long Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string Mobile { get; set; }
        public string Gender { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public ICollection<UserMemberShip> UserMemberShip { get; set; }
        public ICollection<UserProfile> UserProfile { get; set; }
    }
}
