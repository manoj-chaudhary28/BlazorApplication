﻿using System;
using System.Collections.Generic;

namespace BlazorApp.Shared.Model
{
    public partial class UserMemberShip
    {
        public long Id { get; set; }
        public long? UserId { get; set; }
        public string Password { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public Users User { get; set; }
    }
}
