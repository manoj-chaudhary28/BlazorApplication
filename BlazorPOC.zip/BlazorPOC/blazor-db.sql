
CREATE TABLE dbo.Users
(
UserId BIGINT PRIMARY KEY IDENTITY,
FirstName VARCHAR(30),
LastName VARCHAR(30),
EmailAddress VARCHAR(50),
Mobile VARCHAR(10),
Gender VARCHAR(10),
CreateDate DATETIME,
UpdateDate DATETIME
)

CREATE TABLE dbo.UserMemberShip
(
MemberShipId BIGINT PRIMARY KEY IDENTITY,
UserId BIGINT FOREIGN KEY REFERENCES dbo.Users(UserId),
Password VARCHAR(100),
CreateDate DATETIME,
UpdateDate DATETIME
)

CREATE TABLE dbo.UserProfile
(
UserProfileId BIGINT PRIMARY KEY IDENTITY,
UserId BIGINT FOREIGN KEY REFERENCES dbo.Users(UserId),
ProfilePic VARCHAR(100),
CreateDate DATETIME,
UpdateDate DATETIME
)